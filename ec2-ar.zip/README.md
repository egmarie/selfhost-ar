# selfhost-ar
 
--works with webpack-dev-server
--node server.js to start project on localhost:3000
--npm init -y
--npm install
--sudo npm run dev

